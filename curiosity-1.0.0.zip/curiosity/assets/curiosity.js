(() => {
  'use strict';
  const words = window.curiosityWords || {};
  const locale = document.body.dataset.language || 'zh-CN';
  let zone = document.body.dataset.timezone || 'Asia/Shanghai';
  try { new Intl.DateTimeFormat(locale, { timeZone: zone }).format(new Date()); }
  catch (_) { zone = 'Asia/Shanghai'; }
  const zonedParts = (date) => {
    const parts = new Intl.DateTimeFormat('en-CA', { timeZone: zone, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23' }).formatToParts(date);
    return Object.fromEntries(parts.filter(p => p.type !== 'literal').map(p => [p.type, Number(p.value)]));
  };
  document.querySelectorAll('[data-open-dialog]').forEach(button => {
    button.addEventListener('click', () => {
      const dialog = document.getElementById(button.dataset.openDialog);
      if (dialog && typeof dialog.showModal === 'function') dialog.showModal();
    });
  });
  document.querySelectorAll('dialog').forEach(dialog => {
    dialog.querySelector('[data-close-dialog]').addEventListener('click', () => dialog.close());
    dialog.addEventListener('click', event => {
      if (event.target !== dialog) return;
      const box = dialog.getBoundingClientRect();
      if (event.clientX < box.left || event.clientX > box.right || event.clientY < box.top || event.clientY > box.bottom) dialog.close();
    });
  });
  const clock = document.getElementById('clock-time');
  if (clock) {
    const tick = () => {
      const now = new Date();
      const p = zonedParts(now);
      clock.textContent = [p.hour, p.minute, p.second].map(n => String(n).padStart(2, '0')).join(':');
      clock.dateTime = now.toISOString();
      document.getElementById('clock-date').textContent = new Intl.DateTimeFormat(locale, { timeZone: zone, month: 'short', day: 'numeric' }).format(now);
      document.querySelector('.clock-hour').style.transform = `rotate(${p.hour * 30 + p.minute / 2}deg)`;
      document.querySelector('.clock-minute').style.transform = `rotate(${p.minute * 6 + p.second / 10}deg)`;
      document.querySelector('.clock-second').style.transform = `rotate(${p.second * 6}deg)`;
    };
    tick();
    setInterval(tick, 1000);
  }
  const days = document.getElementById('calendar-days');
  if (days) {
    const today = zonedParts(new Date());
    let year = today.year;
    let month = today.month - 1;
    const draw = () => {
      const current = zonedParts(new Date());
      document.getElementById('calendar-month').textContent = new Intl.DateTimeFormat(locale, { month: 'long', year: 'numeric', timeZone: 'UTC' }).format(new Date(Date.UTC(year, month, 1)));
      days.replaceChildren();
      const offset = (new Date(Date.UTC(year, month, 1)).getUTCDay() + 6) % 7;
      const total = new Date(Date.UTC(year, month + 1, 0)).getUTCDate();
      for (let i = 0; i < offset + total; i++) {
        const cell = document.createElement('span');
        if (i >= offset) {
          const day = i - offset + 1;
          cell.textContent = String(day);
          if (year === current.year && month === current.month - 1 && day === current.day) {
            cell.className = 'is-today';
            cell.setAttribute('aria-label', `${words.today || 'Today'} ${day}`);
          }
        } else cell.setAttribute('aria-hidden', 'true');
        days.append(cell);
      }
    };
    const change = amount => {
      const date = new Date(Date.UTC(year, month + amount, 1));
      year = date.getUTCFullYear(); month = date.getUTCMonth(); draw();
    };
    document.getElementById('month-prev').addEventListener('click', () => change(-1));
    document.getElementById('month-next').addEventListener('click', () => change(1));
    document.getElementById('calendar-today').addEventListener('click', () => {
      const current = zonedParts(new Date()); year = current.year; month = current.month - 1; draw();
    });
    draw();
  }
  const checkin = document.getElementById('checkin-button');
  if (checkin) {
    const key = `curiosity-checkins:${document.body.dataset.storageKey}`;
    const count = document.getElementById('checkin-count');
    const status = document.getElementById('checkin-status');
    const dateKey = () => { const p = zonedParts(new Date()); return `${p.year}-${String(p.month).padStart(2, '0')}-${String(p.day).padStart(2, '0')}`; };
    let visits = [];
    try {
      const stored = JSON.parse(localStorage.getItem(key) || '[]');
      if (Array.isArray(stored)) visits = [...new Set(stored.filter(item => typeof item === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(item)))];
    } catch (_) {}
    const update = () => {
      count.textContent = String(visits.length);
      checkin.disabled = visits.includes(dateKey());
      checkin.textContent = checkin.disabled ? (words.checked || 'Checked in') : `${words.checkin || 'Check in'} +`;
    };
    checkin.addEventListener('click', () => {
      const day = dateKey();
      if (visits.includes(day)) { update(); return; }
      const next = [...visits, day];
      try { localStorage.setItem(key, JSON.stringify(next)); visits = next; update(); }
      catch (_) { status.textContent = words.storage_unavailable || 'Local storage is unavailable.'; }
    });
    update();
  }
})();
